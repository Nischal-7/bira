import { Controller, Request, Post, UseGuards, Get, Body, Req, Res } from "@nestjs/common";
import { AppService } from "./app.service";
import { AuthService } from "./auth/auth.service";
import { AuthDto } from "./DTO/auth.dto";
import { ApiTags } from "@nestjs/swagger";
import { LoginDto } from "./DTO/login.dto";

@ApiTags("Login")
@Controller()
export class AppController {


  constructor(private readonly appService: AppService) { }

  getHello(): any {
    throw new Error('Method not implemented.');
  }

  @Get("environment")
  async checkEnvirontment(): Promise<String> {
    return process.env.APP_ENV || 'local'
  }

  // @Post('signup')
  // signUp(@Body() _user: AuthDto) {

  //   return this.appService.signup(_user);
  // }


  @Post('login')
  signIn(@Body() _user: LoginDto, @Req() req, @Res() res) {
    return this.appService.signin(_user, req, res);
  }

  @Get('logout')
  signOut(@Req() req, @Res() res) {

    return this.appService.signout(req, res);
  }

}
