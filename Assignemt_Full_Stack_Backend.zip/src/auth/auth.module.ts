import { Module } from '@nestjs/common';
import { AuthService } from './auth.service';
import { JwtModule } from '@nestjs/jwt';
import { PassportModule } from '@nestjs/passport';
import { TeamController } from 'src/Team/team.controller';
import { EpicController } from 'src/Epic/epic.controller';
import { UserController } from 'src/User/user.controller';
import { ProjectController } from 'src/Project/project.controller';
import { TeamService } from 'src/Team/team.service';
import { PrismaService } from 'src/prisma/prisma.service';
import { EpicService } from 'src/Epic/epic.service';
import { ProjectService } from 'src/Project/project.service';
import { UserService } from 'src/User/user.service';
import * as dotenv from "dotenv";
import { JwtStrategy } from './jwt.strategy';
dotenv.config();


@Module({
  imports: [PassportModule, JwtModule.register({
    secret:process.env.JWT_SECRET,
    signOptions: { expiresIn: "36000s" },
  })],
  controllers: [TeamController, EpicController, UserController, ProjectController],
  providers: [AuthService,JwtStrategy, TeamService, PrismaService, EpicService, ProjectService, UserService],
})
export class AuthModule { }


// import { Module } from "@nestjs/common";
// import { PassportModule } from "@nestjs/passport";
// import { AuthService } from "./auth.service";
// import { LocalStrategy } from "./local.startegy";
// import { JwtModule } from "@nestjs/jwt";
// import { JwtStrategy } from "./jwt.strategy";


// @Module({
//     imports:[PassportModule,JwtModule.register({
//         secret:'test',
//         signOptions:{expiresIn:'360000s'}
//     })],
//     providers:[AuthService,LocalStrategy,JwtStrategy],
//     exports:[AuthService]
// })

// export class AuthModule{

// }