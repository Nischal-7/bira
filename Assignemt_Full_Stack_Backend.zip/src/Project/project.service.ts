import { BadRequestException, ForbiddenException, Injectable } from '@nestjs/common';
import { Request, Response } from 'express';
import { PrismaService } from 'src/prisma/prisma.service';
import { ProjectDto } from 'src/DTO/project.dto';

@Injectable()
export class ProjectService {

    constructor(private prisma: PrismaService) { }




    async insertProject(_project: ProjectDto, req: Request, res: Response) {
        try {
            const foundUser = await this.prisma.project.findUnique({ where: { title: _project.title } })
            if (foundUser) {
                return res.status(201).send({ message: 'Title already exists' })
            }
            const { title, description, start_date, end_date, ownerId, teamId } = _project;
            const result = await this.prisma.project.create({
                data: {
                    title: title,
                    description: description,
                    start_date: start_date,
                    end_date: end_date,
                    ownerId: ownerId,
                    teamId: teamId,
                }
            })
            if (result)
                res.status(200).send({ result })
            else {
                res.status(201).send({ result })
            }
        } catch (e) {
            return res.status(400).send({ message: 'Error Occured', error: e })
        }
    }




    async getAllProject(req: Request, res: Response) {
        try {
            const result = await this.prisma.project.findMany()
            if (result)
                res.status(200).send({ result })
            else {
                res.status(201).send({ result })
            }
        } catch (e) {
            return res.status(400).send({ message: 'Error Occured', error: e })
        }
    }



    async deleteById(id: number, req: Request, res: Response) {
        try {
            const result = await this.prisma.project.delete({ where: { Id: id } })
            if (result)
                res.status(200).send({ deletedProject: result })
            else {
                res.status(201).send({ result })
            }
        } catch (e) {
            return res.status(400).send({ message: 'Error Occured', error: e })
        }
    }




    async updatePatch(_project: { id: number, title?: string, description?: string, start_date?: Date, end_date?: Date, ownerId?: number, teamId: number }, id: number, req: Request, res: Response) {
        try {
            const result = await this.prisma.project.update({
                where: { Id: id },
                data: _project,
            })
            if (result)
                res.status(200).send({ result })
            else {
                res.status(201).send({ result })
            }
        } catch (e) {
            return res.status(400).send({ message: 'Error Occured', error: e })
        }
    }



    async getProjectById(id: number, req: Request, res: Response) {
        try {
            const result = await this.prisma.project.findUnique({
                where: { Id: id }
            })
            if (result)
                res.status(200).send({ result })
            else {
                res.status(201).send({ message:"Result Not Found"})
            }
        } catch (e) {
            return res.status(400).send({ message: 'Error Occured', error: e })
        }
    }

}
