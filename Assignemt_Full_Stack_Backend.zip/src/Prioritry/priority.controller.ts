import { PrismaClient, Priority } from '@prisma/client'
const prisma = new PrismaClient()
import { Body, Controller, Delete, Get, Param, Patch, Post, UseGuards } from '@nestjs/common';
// import { JwtAuthGuard } from '../auth/auth.guard';
import { ApiBody, ApiTags } from '@nestjs/swagger';
import { PriorityService } from './priority.service';
 
@Controller('priority')
@ApiTags('Priority')
export class PriorityController {
    constructor(private readonly priorityService: PriorityService) { }
 
    @Get()
    // @UseGuards(JwtAuthGuard)
    getAll(): Promise<Priority[] | object> {
        return this.priorityService.findAll();
    }
}