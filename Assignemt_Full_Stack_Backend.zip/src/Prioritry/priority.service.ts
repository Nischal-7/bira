import { Injectable } from '@nestjs/common';
import { Prisma, Priority, User } from '@prisma/client';
import { PrismaService } from 'src/prisma/prisma.service';
 
@Injectable()
export class PriorityService {
    constructor(private prisma: PrismaService) { }
 
    async findAll(): Promise<Priority[] | object> {
        try {
            const NEW_DATA = await this.prisma.priority.findMany()
            return {
                status: 200,
                message: "Success",
                response: NEW_DATA
            }
        } catch (e) {
            return {
                status: 404,
                message: "Failure",
                response: e
            }
        }
    }
}