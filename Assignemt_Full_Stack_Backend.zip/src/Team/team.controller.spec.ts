import { Test, TestingModule } from '@nestjs/testing';
import { TeamController } from './team.controller';
import { TeamDto } from 'src/DTO/team.dto';
import { JwtAuthGuard } from 'src/auth/jwt.guard';
import { JwtStrategy } from 'src/auth/jwt.strategy';
import { TeamService } from './team.service';

describe('TeamController', () => {
  let controller: TeamController;
  let service: TeamService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [TeamController],
      providers: [TeamService, JwtAuthGuard, JwtStrategy],
    }).compile();

    controller = module.get<TeamController>(TeamController);
    service = module.get<TeamService>(TeamService);
  });

  describe('addTeam', () => {
    it('should add a new team', async () => {
      const mockTeam: TeamDto = {
        id:1,
        name: 'New Team',
        projectId: 1,
      };
      const mockReq = { user: { userId: 1 } };
      const mockRes = {};

      jest.spyOn(service, 'insertTeam').mockResolvedValueOnce(mockTeam);

      const result = await controller.addTeam(mockTeam, mockReq, mockRes);

      expect(result).toEqual(mockTeam);
    });
  });

  describe('getAll', () => {
    it('should get all teams', async () => {
      const mockTeams: TeamDto[] = [
        {id:1, name: 'Team 1', projectId: 2 },
        { id:2,name: 'Team 2', projectId: 3 },
      ];
      const mockReq = { user: { userId: 1 } };
      const mockRes = {};

      jest.spyOn(service, 'getAllTeam').mockResolvedValueOnce(mockTeams);

      const result = await controller.getAll(mockReq, mockRes);

      expect(result).toEqual(mockTeams);
    });
  });

  describe('getTeamId', () => {
    it('should get a team by ID', async () => {
      const mockTeam: TeamDto = {
        id:1,
        name: 'New Team',
        projectId: 1,
      };
      const mockReq = { user: { userId: 1 } };
      const mockRes = {};
      const mockId = 1;

      jest.spyOn(service, 'getTeamById').mockResolvedValueOnce(mockTeam);

      const result = await controller.getTeamId(mockId, mockReq, mockRes);

      expect(result).toEqual(mockTeam);
    });
  });
});
