import { Controller, Request, Post, UseGuards, Get, Body, Req, Res, Param } from "@nestjs/common";
import { ApiBearerAuth, ApiBody, ApiTags } from "@nestjs/swagger";
import { TeamService } from "src/Team/team.service";
import { TeamDto } from "src/DTO/team.dto";
import { JwtAuthGuard } from "src/auth/jwt.guard";
import { JwtStrategy } from "src/auth/jwt.strategy";
import { jwtSecret } from "src/utils/contants";

@ApiTags("Team")
@Controller('team')
@ApiBearerAuth()
export class TeamController {


    constructor(private readonly teamService: TeamService) { }


    @Post()
    @UseGuards(JwtAuthGuard)
    addTeam(@Body() _team: TeamDto, @Req() req, @Res() res) {
        return this.teamService.insertTeam(_team, req, res);
    }


    @Get()
    @UseGuards(JwtAuthGuard)
    getAll(@Req() req, @Res() res) {
        return this.teamService.getAllTeam(req, res);
    }


    @Get(':id')
    @UseGuards(JwtAuthGuard)
    getTeamId(@Param('id') id: number,
        @Req() req, @Res() res) {
        return this.teamService.getTeamById(+id, req, res);
    }
}
