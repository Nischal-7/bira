import { Module } from "@nestjs/common";


// import { UserModule } from "./user/user.module";

// import { TeamModule } from "./team/team.module";

import { ConfigModule } from "@nestjs/config";
import { JwtModule, JwtService } from "@nestjs/jwt";
import { PrismaModule } from "src/prisma/prisma.module";
import { TeamController } from "./team.controller";
import { TeamService } from "./team.service";
import { JwtStrategy } from "src/auth/jwt.strategy";

@Module({
  imports: [
    // ConfigModule.forRoot({isGlobal: true}),
    // UserModule,
    // TeamModule,
    JwtModule,
  
    PrismaModule
    
  ],

  controllers: [TeamController],
  providers: [TeamService, JwtService,JwtStrategy],
})
export class TeamModule {}
