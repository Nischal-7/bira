import { Injectable } from '@nestjs/common';
import { Prisma, Status, User } from '@prisma/client';
import { PrismaService } from 'src/prisma/prisma.service';
 
@Injectable()
export class TypeService {
    constructor(private prisma: PrismaService) { }
 
    async findAll(): Promise<Status[] | object> {
        try {
            const result = await this.prisma.type.findMany()
            return {
                status:200,
                message: "Success",
                response: result
            }
        } catch (e) {
            return {
                status: 404,
                message: "Failure",
                response: e
            }
        }
    }
}
