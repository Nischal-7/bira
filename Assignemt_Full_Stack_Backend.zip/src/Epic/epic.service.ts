import { BadRequestException, ForbiddenException, Injectable } from '@nestjs/common';
import { Request, Response } from 'express';
import { PrismaService } from 'src/prisma/prisma.service';
import { EpicDto } from 'src/DTO/Epic.dto';
import { PrismaClient } from '@prisma/client';

@Injectable()
export class EpicService {



    constructor(private prisma: PrismaService) { }

    async insertEpicData(_epic: EpicDto, req: Request, res: Response) {
        try {
            const foundUser = await this.prisma.epic.findUnique({ where: { title: _epic.title } })
            if (foundUser) {
                throw new BadRequestException('Title already exists')
            }
            else {
                const checkStatus = await this.prisma.status.findUnique({ where: { Id: _epic.statusId } })
                const chekProject = await this.prisma.project.findUnique({ where: { Id: _epic.projectId } })
                if (checkStatus && chekProject) {
                    const result = await this.prisma.epic.create({
                        data: _epic
                    })
                    return res.status(200).send({ message: 'Data Inserted Sucessfully', data: result })

                } else {
                    return res.status(201).send({ message: "Project ID or Status Id doesn't exist " })
                }
            }
        }
        catch (e) {
            return res.status(400).send({ message: 'Error Occured', error: e })

        }
    }
    getDataFromPage(page: number, req: Request, res: Response) {
        throw new Error("Method not implemented.");
    }

    async getByProjectIdData(projectId: number, req: Request, res: Response) {
        try {
            const getByProject = await this.prisma.epic.findMany({
                where: { projectId: projectId },
                include: {
                    Issue: {}
                }
            })
            if (getByProject) {
                return res.status(200).send({
                    message: "Sucess",
                    res: getByProject
                })
            } else {
                return res.status(201).send({
                    message: "Sucess",
                    res: "Project Id is doesn't exist"
                })
            }
        } catch (e) {
            return res.status(400).send({
                message: "Error Occured",
                error: e
            })
        }
    }



    async deleteEpicDataById(id: number, req: Request, res: Response) {
        try {
            const result = await this.prisma.epic.delete({ where: { Id: id } })
            if (result)
                res.status(200).send({ deletedEpic: result })
            else {
                res.status(201).send({ message:"Data not Found" })
            }
        } catch (e) {
            return res.status(400).send({ message: 'Error Occured', error: e })
        }
    }



    async updatePathDataById(id: number, _data, req: Request, res: Response) {
        try {
            const getEpic = await this.prisma.epic.findUnique({ where: { Id: id } })
            if (getEpic) {
                const updateData = await this.prisma.epic.update(
                    {
                        where: { Id: id },
                        data: _data
                    }
                )
                return res.status(200).send({ message: "Record has been update sucessfully", data: updateData })
            } else {
                return res.status(201).send({ message: "Data not found" })
            }
        } catch (e) {
            return res.status(404).send({ message: "Error Occured", error: e })
        }
    }


    async getDataById(id: number, req: Request, res: Response) {
        try {
            const result = await this.prisma.epic.findUnique({
                where: { Id: id }
            })
            if (result)
                res.status(200).send({ result })
            else {
                res.status(201).send({ message: "Data Not Found" })
            }
        } catch (e) {
            return res.status(400).send({ message: 'Error Occured', error: e })
        }
    }








}
