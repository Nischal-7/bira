import { ApiProperty } from "@nestjs/swagger";
import { IsDate, IsEmail, IsNotEmpty, IsNumber, IsString, Length } from "class-validator";

export class IssueDto{

    public Id:number

    @IsNotEmpty()
    @IsString()
    @ApiProperty()
    public title:string

    @IsString()
    @ApiProperty()
    @IsNotEmpty()
    public description:string


    @IsNumber()
    @ApiProperty()
    @IsNotEmpty()
    public assigneeId:number


    @IsNumber()
    @ApiProperty()
    @IsNotEmpty()
    public reporterId:number

    @IsNumber()
    @ApiProperty()
    @IsNotEmpty()
    public typeId:number

    @IsNumber()
    @ApiProperty()
    @IsNotEmpty()
    public statusId:number


    @IsNumber()
    @ApiProperty()
    @IsNotEmpty()
    public priorityId:number


    @ApiProperty()
    public start_date:Date

    @ApiProperty()
    public end_date:Date

    // @IsDate()
    // @ApiProperty({
    //     type: Date,
    //     format: 'date-time', // specify the format as date-time
    //     example: '2023-04-15T14:30:00.000Z', // provide an example of the date
    //   })
    //   public end_date: Date;


    @ApiProperty()
    @IsNotEmpty()
    public epicId:number
    
}

