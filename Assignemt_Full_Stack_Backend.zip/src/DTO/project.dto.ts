import { ApiProperty } from "@nestjs/swagger";
import { IsDate, IsEmail, IsNotEmpty, IsNumber, IsString, Length, isNumber } from "class-validator";

export class ProjectDto{

    public id:number

    @IsNotEmpty()
    @ApiProperty()
    @IsString()
    public title:string

    @IsNotEmpty()
    @ApiProperty()
    @IsString()
    public description:string


    @ApiProperty()
    public start_date:Date

    @ApiProperty()
    public end_date:Date


    @ApiProperty()
    public ownerId:number

    public teamId:number
}


