import { ApiProperty } from '@nestjs/swagger';
import { IsEnum, IsNotEmpty, IsOptional, IsString } from 'class-validator';
import { Transform } from 'class-transformer';

enum HttpMethod {
  GET = 'GET',
  POST = 'POST',
  PUT = 'PUT',
  PATCH = 'PATCH',
  DELETE = 'DELETE',
}

export class AuditDto {
  @ApiProperty({
    enum: HttpMethod,
    example: 'POST',
    description: 'HTTP method used in the request',
  })
  @IsEnum(HttpMethod)
  public method: string;

  @ApiProperty({
    example: 'users',
    description: 'Name of the action table',
  })
  @IsNotEmpty()
  @IsString()
  public actionTable: string;

  @ApiProperty({
    example: '{"name": "John Doe"}',
    description: 'JSON representation of request data',
  })
  @Transform(({ value }) => JSON.parse(value))
  public changeJson: Record<string, unknown>;

  @ApiProperty({
    example: '2023-04-13T13:30:00Z',
    description: 'Timestamp of when the request was executed',
  })
  @IsNotEmpty()
  @IsString()
  public timestamp: string;

  @ApiProperty({
    example: 'John Doe',
    description: 'Name of the user who made the request',
  })
  @IsOptional()
  @IsString()
  public auditUser?: string;

  @ApiProperty({
    example: 200,
    description: 'HTTP status code of the response',
  })
  @IsNotEmpty()
  @IsString()
  public statusCode: number;
}
