-- DropIndex
DROP INDEX "Issue_title_key";
